
function savename(){

   var p1 = document.getElementById("firstPl").value.trim();
   var p2 = document.getElementById("secondPl").value.trim();
   var p3 = document.getElementById("thirdPl").value.trim();
   var p4 = document.getElementById("fourthPl").value.trim();
   path ="game.html?p1="+p1 +"&p2=" +p2 +"&p3="+p3 +"&p4="+p4;
   if(p1==""||p2==""||p3==""||p4=="")
   {
   	alert("Please enter all the Players Name");
   }
   else
   {
	window.open(path);
	this.window.close();
};
};



function prefil(){
	//get all the player names from url
	var link =window.location.href;
	var url = new URL(link);
	var plname1 = url.searchParams.get("p1");
	var plname2 = url.searchParams.get("p2");
	var plname3 = url.searchParams.get("p3");
	var plname4 = url.searchParams.get("p4");

	document.getElementById("firstPl").innerHTML = plname1;
	document.getElementById("secondPl").innerHTML = plname2;
	document.getElementById("thirdPl").innerHTML = plname3;
	document.getElementById("fourthPl").innerHTML = plname4;

//make invisble to all the chor-sipahi block
	var qst1= document.getElementById("quest1");
	qst1.style.display="none";

	var qst2= document.getElementById("quest2");
	qst2.style.display="none";

	var qst3= document.getElementById("quest3");
	qst3.style.display="none";

	var qst4= document.getElementById("quest4");
	qst4.style.display="none";
};

var a = 0;
//for first player
function ranChoP1(){
	var p2num = document.getElementById("gotRanP2").innerHTML;
	var p3num = document.getElementById("gotRanP3").innerHTML;
	var p4num = document.getElementById("gotRanP4").innerHTML;
	var num = Math.floor((Math.random()*4)+1);
	return (num == p2num || num == p3num || num == p4num ) ? ranChoP1() : num;
};
var score =0;
function assingvalueP1(){
	var randomnum = ranChoP1();
	var score = document.getElementById("score1").innerHTML;
	document.getElementById("gotRanP1").innerHTML =randomnum;

	switch(randomnum){
		case 1: 
		document.getElementById("place1").innerHTML = "Raja";
		a = a+100;
		document.getElementById("score1").innerHTML = a;
	}
};


//for third player
function ranChoP3(){
	var p1num = document.getElementById("gotRanP1").innerHTML;
	var p2num = document.getElementById("gotRanP2").innerHTML;
	var p4num = document.getElementById("gotRanP4").innerHTML;
	var num = Math.floor((Math.random()*4)+1);
	return (num == p1num || num == p2num || num == p4num ) ? ranChoP3() : num;
};

function assingvalueP3(){
	var num = ranChoP3();
	document.getElementById("gotRanP3").innerHTML =num;
};

//for fourth player
function ranChoP4(){
	var p1num = document.getElementById("gotRanP1").innerHTML;
	var p3num = document.getElementById("gotRanP3").innerHTML;
	var p2num = document.getElementById("gotRanP2").innerHTML;
	var num = Math.floor((Math.random()*4)+1);
	return (num == p1num || num == p3num || num == p2num ) ? ranChoP4() : num;
};


function assingvalueP4(){
	var num = ranChoP4();
	document.getElementById("gotRanP4").innerHTML =num;

};

//for second player
function ranChoP2(){
	var p1num = document.getElementById("gotRanP1").innerHTML;
	var p3num = document.getElementById("gotRanP3").innerHTML;
	var p4num = document.getElementById("gotRanP4").innerHTML;
	var num = Math.floor((Math.random()*4)+1);
	return (num == p1num || num == p3num || num == p4num ) ? ranChoP2() : num;
};

function assingvalueP2(){
	var num = ranChoP2();
	document.getElementById("gotRanP2").innerHTML =num;
};

//refresh button
var i =0;
function refreshbtn(){
		i= i+1;
	 	document.getElementById("gotRanP1").innerHTML=0;
	 	document.getElementById("gotRanP2").innerHTML=0;
	 	document.getElementById("gotRanP3").innerHTML=0;
		document.getElementById("gotRanP4").innerHTML=0;
		document.getElementById("rnd-btn").value ="Round"+i;
};

