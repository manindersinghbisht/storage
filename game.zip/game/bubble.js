function topleft(){
document.getElementById("buddle").style.backgroundColor ="yellow";
document.getElementById("buddle").style.position = "absolute";
document.getElementById("buddle").style.left="2%";
document.getElementById("buddle").style.top="2%";

window.setTimeout(topcenter, 1000);
};

function topcenter(){
document.getElementById("buddle").style.backgroundColor ="green";
document.getElementById("buddle").style.position = "absolute";
document.getElementById("buddle").style.left="46%";

window.setTimeout(topright, 1000);
};
function topright(){
	document.getElementById("buddle").style.backgroundColor ="orange";
	document.getElementById("buddle").style.position = "absolute";
	document.getElementById("buddle").style.left="94%";
	window.setTimeout(rightcenter, 1000);
};
function rightcenter(){
	document.getElementById("buddle").style.backgroundColor ="red";
	document.getElementById("buddle").style.position = "absolute";
	document.getElementById("buddle").style.left="94%";
	document.getElementById("buddle").style.top="46%";
	window.setTimeout(rightBottom, 1000);
};
function rightBottom(){
	document.getElementById("buddle").style.backgroundColor ="blue";
	document.getElementById("buddle").style.position = "absolute";
	document.getElementById("buddle").style.left="94%";
	document.getElementById("buddle").style.top="94%";
	window.setTimeout(centerBottom, 1000);
};

function centerBottom(){
	document.getElementById("buddle").style.backgroundColor ="pink";
	document.getElementById("buddle").style.position = "absolute";
	document.getElementById("buddle").style.left="46%";
	document.getElementById("buddle").style.top="94%";
	window.setTimeout(leftBottom, 1000);
};
function leftBottom(){
	document.getElementById("buddle").style.backgroundColor ="black";
	document.getElementById("buddle").style.position = "absolute";
	document.getElementById("buddle").style.left="2%";
	document.getElementById("buddle").style.top="94%";
	window.setTimeout(leftcenter, 1000);
};

function leftcenter(){
	document.getElementById("buddle").style.backgroundColor ="brown";
	document.getElementById("buddle").style.position = "absolute";
	document.getElementById("buddle").style.left="2%";
	document.getElementById("buddle").style.top="46%";
	window.setTimeout(topleft, 1000);
};

topleft();
