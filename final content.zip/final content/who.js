
//move email to right-bottom
var pos =0;
function move(){ 

if (pos == 90){

}
else{
	
	document.getElementById("sub-main").style.top= pos +"%";
 	document.getElementById("sub-main").style.left= pos+1 +"%";
	pos = pos+10;

setTimeout(move,200);
}
};
move();
