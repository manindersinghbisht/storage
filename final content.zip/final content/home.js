
function savename(){

   var name = document.getElementById("firstPl").value.trim();
   var ph = document.getElementById("secondPl").value.trim();
   var email = document.getElementById("thirdPl").value.trim();
   var address = document.getElementById("fourthPl").value.trim();
   path ="who.html?name="+name;
   if(name==""||ph==""||email==""||address=="")
   {
   	alert("Please enter all information");
   }
   else
   {
  
	window.open(path);
	this.window.close();
};
};



