function preloadfxn() {
	var link = window.location.href;
var url = new URL(link);
name = url.searchParams.get("name");
if (name=="null"){
	document.getElementById("pre-desc").innerHTML ="Hi Visitor,</br> Thank you for visiting our website! we are glade that you visited Us";

}
else{
document.getElementById("pre-desc").innerHTML ="Hi "+name +",</br> Thank you for visiting our website! we are glade that you visited Us";
}
setTimeout(descfxn,5000);
};

function descfxn(){
	document.getElementById("pre-desc").style.display ="none";
document.getElementById("desc").style.display = "block";
}