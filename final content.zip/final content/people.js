function gotoseven(){
	var elmnt;
	 elmnt= document.getElementById("seventhclass");
    elmnt.scrollIntoView();
}